CREATE TABLE issues(
    id BIGINT PRIMARY KEY,
    repository TEXT NOT NULL,
    number INT NOT NULL,
    url TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT,
    state TEXT NOT NULL,
    state_reason TEXT,
    created_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL,
    closed_at TIMESTAMPTZ,
    labels TEXT[] NOT NULL,
    comment_count INT NOT NULL,
    collected_at TIMESTAMPTZ NOT NULL
);

SELECT state, COUNT(DISTINCT id) AS issue_count
FROM issues
GROUP BY state
ORDER BY state;

-- Counts should agree with the saved JSON. The outside-range count should be 0.
SELECT COUNT(*) AS total_issues,
       COUNT(DISTINCT id) AS unique_ids,
       COUNT(*) FILTER (WHERE repository <> 'openai/codex'
           OR created_at < TIMESTAMPTZ '2026-11-01 00:00:00+00'
           OR created_at >= TIMESTAMPTZ '2026-11-08 00:00:00+00') AS outside_cohort
FROM issues;

-- Group dates in UTC to match GitHub's creation timestamps.
SELECT (created_at AT TIME ZONE 'UTC')::date AS created_date,
       COUNT(*) AS issue_count
FROM issues
GROUP BY created_date
ORDER BY created_date;

-- An issue can have several labels, so these counts are not additive.
SELECT label, COUNT(DISTINCT id) AS issue_count
FROM issues
CROSS JOIN LATERAL unnest(labels) AS label
GROUP BY label
ORDER BY issue_count DESC, label;
