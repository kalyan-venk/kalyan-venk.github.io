"""Refresh the fixed reporting cohort. Raw downloads are saved before database work."""
import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path

from fetch_issues import REPO, WINDOW, collect, save_batch
from load_issues import connect, load


def apply_batch(conn, path):
    raw = path.read_bytes()
    batch = json.loads(raw)
    signature = hashlib.sha256(raw).hexdigest()
    if batch["repository"] != REPO or batch["created_range"] != WINDOW:
        raise ValueError("Snapshot belongs to a different repository or cohort")
    with conn.transaction():
        # Serialize writers and keep the checkpoint in the transaction with the observations.
        conn.execute("SELECT pg_advisory_xact_lock(742321159)")
        prior = conn.execute("SELECT digest FROM compass.refresh_runs WHERE collected_at=%s",
                             (batch["collected_at"],)).fetchone()
        if prior:
            if prior[0] != signature:
                raise ValueError("Different input at an already committed observation time")
            return {"replayed": True, "received": len(batch["issues"]), "inserted_observations": 0}
        last = conn.execute("SELECT max(started_at) FROM compass.refresh_runs").fetchone()[0]
        start = datetime.fromisoformat(batch["started_at"])
        if last and start <= last:
            raise ValueError("A newer run already committed; fetch again")
        baseline = conn.execute("SELECT min(collected_at) FROM compass.baseline_issues").fetchone()[0]
        if baseline is None:
            raise ValueError("Load the November 14 baseline before refreshing")
        if batch["since"] and datetime.fromisoformat(batch["since"]) > (last or baseline):
            raise ValueError("Delta starts after the last verified checkpoint")
        if datetime.fromisoformat(batch["collected_at"]) < start:
            raise ValueError("Collection finished before it started")
        changed = load(conn, batch)
        if conn.execute("""SELECT EXISTS (SELECT FROM incoming i LEFT JOIN compass.baseline_issues b
                           USING (id) WHERE b.id IS NULL OR i.number <> b.number OR i.repository <> b.repository)""").fetchone()[0]:
            raise ValueError("Received an ID outside the frozen cohort")
        if batch["since"] is None and conn.execute("""SELECT EXISTS (
                SELECT id FROM compass.baseline_issues EXCEPT SELECT id FROM incoming)""").fetchone()[0]:
            raise ValueError("Full collection omitted baseline IDs; review source coverage")
        if conn.execute("""SELECT EXISTS (SELECT FROM incoming i LEFT JOIN public.issues p USING(id)
                           WHERE to_jsonb(i) IS DISTINCT FROM to_jsonb(p))""").fetchone()[0]:
            raise ValueError("Source-to-database reconciliation failed")
        n = conn.execute("""INSERT INTO compass.issue_observations
              (repository,id,collected_at,number,url,title,state,created_at,labels)
              SELECT repository,id,collected_at,number,url,title,state,created_at,labels FROM incoming""").rowcount
        conn.execute("INSERT INTO compass.refresh_runs VALUES (%s,%s,%s,%s,%s,%s)",
                     (batch["collected_at"], start, batch["since"], signature, n, changed))
        return {"replayed": False, "received": n, "inserted_observations": n, "changed_records": changed}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--full", action="store_true", help="Reobserve the entire original cohort")
    mode.add_argument("--replay", type=Path, help="Resume or verify an already downloaded batch")
    args = parser.parse_args()
    with connect() as conn:
        last = conn.execute("SELECT max(started_at) FROM compass.refresh_runs").fetchone()[0]
        path = args.replay or save_batch(collect(None if args.full else last))
        print(path, flush=True)
        print(json.dumps(apply_batch(conn, path)), flush=True)


if __name__ == "__main__":
    main()
