-- Read-only checks. Every row must pass; the transaction fails on a mismatch.
BEGIN;
CREATE TEMP TABLE reporting_checks ON COMMIT DROP AS
WITH pairs AS (SELECT * FROM compass.baseline_memberships),
fixture AS (
    SELECT * FROM pairs
    UNION ALL
    (SELECT * FROM pairs ORDER BY id, label LIMIT 1)
)
SELECT test, actual, expected, actual = expected AS passed
FROM (VALUES
    ('Issues in the frozen cohort', (SELECT count(*) FROM compass.baseline_issues), 1159),
    ('Open bugs', (SELECT count(*) FROM compass.baseline_issues
                   WHERE state = 'open' AND 'bug' = ANY(labels)), 882),
    ('Distinct selected reports', (SELECT count(DISTINCT id) FROM pairs), 459),
    ('Issue-level review rows', (SELECT count(*) FROM compass.baseline_review), 459),
    ('Selected label memberships', (SELECT count(*) FROM pairs), 543),
    ('Connectivity reports', (SELECT count(DISTINCT id) FROM pairs WHERE label = 'connectivity'), 100),
    ('Repeated issue-label pairs', (SELECT count(*) - count(DISTINCT (id, label)) FROM pairs), 0),
    ('Null or orphan labels', (SELECT count(*) FROM compass.issue_labels l
                               LEFT JOIN compass.issue_observations o USING (repository, id, collected_at)
                               WHERE o.id IS NULL OR nullif(trim(l.label), '') IS NULL), 0),
    ('Injected duplicate pairs detected', (SELECT count(*) - count(DISTINCT (id, label)) FROM fixture), 1),
    ('Two-label union agrees with issue view',
     (SELECT count(DISTINCT id) FROM pairs WHERE label IN ('connectivity','auth')),
     (SELECT count(*) FROM compass.baseline_review WHERE selected_labels && ARRAY['connectivity','auth']))
) AS checks(test, actual, expected);

SELECT * FROM reporting_checks;
DO $$
DECLARE failures text;
BEGIN
    SELECT string_agg(test, ', ' ORDER BY test) INTO failures FROM reporting_checks WHERE NOT passed;
    IF failures IS NOT NULL THEN RAISE EXCEPTION 'Failed checks: %', failures; END IF;
END $$;
ROLLBACK;
