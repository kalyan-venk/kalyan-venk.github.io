"""Fetch a complete, dated batch of public Codex issues in the fixed creation window."""
import json
import os
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from tempfile import NamedTemporaryFile
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parent
REPO = "openai/codex"
WINDOW = "2026-11-01..2026-11-07"


def utcnow():
    return datetime.now(timezone.utc)


def collect(since=None):
    started = utcnow()
    issues = {}
    requests = 0
    earliest = since - timedelta(minutes=5) if since else None
    headers = {"User-Agent": "Product-Compass", "Accept": "application/vnd.github+json"}
    if token := os.environ.get("GH_TOKEN"):
        headers["Authorization"] = f"Bearer {token}"
    for day in range(1, 8):
        date = f"2026-11-{day:02d}"
        query = f"repo:{REPO} is:issue created:{date}"
        if earliest:
            query += " updated:>=" + earliest.strftime("%Y-%m-%dT%H:%M:%SZ")
        page = 1
        received = 0
        expected = None
        while True:
            params = urlencode(dict(q=query, page=page, per_page=100, sort="created", order="asc"))
            if requests:
                time.sleep(2.2 if "Authorization" in headers else 7)
            with urlopen(Request(f"https://api.github.com/search/issues?{params}", headers=headers), timeout=40) as result:
                data = json.load(result)
            requests += 1
            if expected is None:
                expected = data["total_count"]
            if data["incomplete_results"] or expected != data["total_count"] or expected > 1000:
                raise ValueError(f"Incomplete or changing search result for {date}; retry the batch")
            for issue in data["items"]:
                if (issue["id"] in issues or "pull_request" in issue
                        or issue["created_at"][:10] != date
                        or issue["repository_url"] != f"https://api.github.com/repos/{REPO}"):
                    raise ValueError(f"Unexpected source record on {date}")
                issues[issue["id"]] = issue
            received += len(data["items"])
            if received == expected:
                break
            if not data["items"] or received > expected:
                raise ValueError(f"Incomplete page for {date}")
            page += 1
    return dict(repository=REPO, created_range=WINDOW, started_at=started.isoformat(),
                collected_at=utcnow().isoformat(), since=earliest.isoformat() if earliest else None,
                requests=requests, issues=list(issues.values()))



def save_batch(batch):
    directory = ROOT / "data"
    directory.mkdir(exist_ok=True)
    stamp = datetime.fromisoformat(batch["collected_at"]).strftime("%Y%m%dT%H%M%S%fZ")
    path = directory / f"codex_{stamp}.json"
    with NamedTemporaryFile("w", encoding="utf-8", dir=directory, delete=False) as temp:
        try:
            json.dump(batch, temp, ensure_ascii=False)
            temp.flush()
            os.link(temp.name, path)
        finally:
            Path(temp.name).unlink(missing_ok=True)
    return path


if __name__ == "__main__":
    print(save_batch(collect()))
