"""Load an issue snapshot without replacing newer observations with older values."""
import argparse
import gzip
import json
import os
from pathlib import Path

import psycopg

ROOT = Path(__file__).resolve().parent
COLUMNS = ("id", "repository", "number", "url", "title", "body", "state", "state_reason",
           "created_at", "updated_at", "closed_at", "labels", "comment_count", "collected_at")


def connect():
    return psycopg.connect(os.environ.get("DATABASE_URL", "dbname=product_compass host=127.0.0.1"),
                           autocommit=True)


def mapped_rows(batch):
    return [(i["id"], batch["repository"], i["number"], i["html_url"], i["title"], i["body"],
             i["state"], i["state_reason"], i["created_at"], i["updated_at"], i["closed_at"],
             [label["name"] for label in i["labels"]], i["comments"], batch["collected_at"])
            for i in batch["issues"]]


def read_snapshot(path):
    payload = path.read_bytes()
    return json.loads(gzip.decompress(payload) if path.suffix == ".gz" else payload)


def load(conn, batch):
    columns = ", ".join(COLUMNS)
    conn.execute("CREATE TEMP TABLE incoming (LIKE public.issues INCLUDING DEFAULTS, PRIMARY KEY (id)) ON COMMIT DROP")
    with conn.cursor().copy(f"COPY incoming ({columns}) FROM STDIN") as copy:
        for row in mapped_rows(batch):
            copy.write_row(row)
    if conn.execute("""SELECT EXISTS (SELECT FROM incoming i JOIN public.issues p USING (id)
                       WHERE i.collected_at = p.collected_at AND to_jsonb(i) <> to_jsonb(p))""").fetchone()[0]:
        raise ValueError("Conflicting issue values at the same observation time")
    changed = conn.execute("""
        SELECT count(*) FROM incoming i LEFT JOIN public.issues p USING (id)
        WHERE p.id IS NULL OR (to_jsonb(i) - 'collected_at') <> (to_jsonb(p) - 'collected_at')
    """).fetchone()[0]
    assignments = ", ".join(f"{c}=EXCLUDED.{c}" for c in COLUMNS[1:])
    conn.execute(f"""INSERT INTO public.issues ({columns}) SELECT {columns} FROM incoming
                     ON CONFLICT (id) DO UPDATE SET {assignments}
                     WHERE issues.collected_at <= EXCLUDED.collected_at""")
    return changed


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("snapshot", nargs="?", type=Path, default=ROOT / "data/codex_issues.json")
    with connect() as conn, conn.transaction():
        batch = read_snapshot(parser.parse_args().snapshot)
        print(f"{load(conn, batch)} changed records")
