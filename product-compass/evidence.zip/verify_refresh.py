"""Reproduce the interruption, replay and full-versus-delta checks in a disposable database."""
import argparse
import json
from pathlib import Path
from uuid import uuid4

import psycopg
from psycopg import sql
from psycopg.conninfo import make_conninfo

from load_issues import ROOT, connect, load, read_snapshot
from refresh import apply_batch


def check(db, baseline, full, delta):
    db.execute((ROOT / "issues.sql").read_text())
    with db.transaction():
        load(db, read_snapshot(baseline))
    db.execute((ROOT / "reporting.sql").read_text())
    db.execute((ROOT / "check_reporting.sql").read_text())
    def totals():
        return db.execute("""SELECT (SELECT count(*) FROM compass.issue_observations),
                             (SELECT count(*) FROM compass.refresh_runs),
                             (SELECT max(collected_at) FROM public.issues)""").fetchone()
    before = totals()
    with db.transaction(force_rollback=True):
        apply_batch(db, delta)
        assert totals()[1] == 1
    assert totals() == before, "Interrupted load advanced the data or checkpoint"
    result = apply_batch(db, delta)
    committed = totals()
    assert apply_batch(db, delta)["replayed"] and totals() == committed
    with db.transaction(force_rollback=True):
        db.execute("CREATE TEMP TABLE delta_result AS SELECT to_jsonb(i)-'collected_at' AS record FROM public.issues i")
        load(db, read_snapshot(full))
        different = db.execute("""
            WITH full_data AS (SELECT to_jsonb(i)-'collected_at' AS record FROM incoming i)
            SELECT (SELECT count(*) FROM (TABLE delta_result EXCEPT TABLE full_data) d)
                 + (SELECT count(*) FROM (TABLE full_data EXCEPT TABLE delta_result) d)
        """).fetchone()[0]
        assert different == 0, f"{different} differing projected records"
    return dict(delta=result, full_rows=before[0], differences=different,
                observations_after_replay=committed[0], interrupted_checkpoint_advanced=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("baseline","full","delta"):
        parser.add_argument(arg, type=Path)
    args = parser.parse_args()
    with connect() as admin:
        name = "compass_verify_" + uuid4().hex
        admin.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(name)))
        try:
            with psycopg.connect(make_conninfo(admin.info.dsn, dbname=name), autocommit=True) as db:
                print(json.dumps(check(db, args.baseline, args.full, args.delta)))
        finally:
            admin.execute(sql.SQL("DROP DATABASE {}").format(sql.Identifier(name)))
