"""Check a frozen title-only screening rule against a held-out reading of report bodies."""
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BLOCK_WORD = re.compile(r"\b(?:cannot|can't|unable|fails?|failed|failure|hangs?|crash(?:es|ed)?|stuck|blocked|unavailable|timed? out)\b", re.I)


def sample_numbers(issues, reviewed):
    return sorted(set(issues)-set(reviewed),
                  key=lambda n: hashlib.sha256(f"compass-holdout-v1/{n}".encode()).digest())[:24]


def evaluate():
    labels = json.loads((ROOT/"holdout-review.json").read_text())
    if len(labels) != 24 or len({r["number"] for r in labels}) != 24:
        raise ValueError("Expected 24 distinct held-out reports")
    results = {"true_positive": [], "false_positive": [], "true_negative": [], "false_negative": [], "unclear": []}
    for row in labels:
        n, label = row["number"], row["classification"]
        if label == "unclear":
            results["unclear"].append(n)
            continue
        if label not in {"blocked","degraded"}:
            raise ValueError(label)
        flagged = bool(BLOCK_WORD.search(row["title"].replace("’","'")))
        correct = flagged == (label == "blocked")
        key = ("true" if correct else "false") + ("_positive" if flagged else "_negative")
        results[key].append(n)
    return results


if __name__ == "__main__":
    print(json.dumps(evaluate()))
