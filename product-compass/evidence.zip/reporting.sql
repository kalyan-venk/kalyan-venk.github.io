-- Run in product_compass after the loader. Re-run after each successful collection.
BEGIN ISOLATION LEVEL REPEATABLE READ;
CREATE SCHEMA IF NOT EXISTS compass;
CREATE TABLE IF NOT EXISTS compass.refresh_runs (
    collected_at timestamptz PRIMARY KEY,
    started_at timestamptz NOT NULL,
    since timestamptz,
    digest text NOT NULL,
    received integer NOT NULL,
    changed integer NOT NULL
);

-- Keep the reporting fields as they were observed, even after public.issues is updated.
CREATE TABLE IF NOT EXISTS compass.issue_observations (
    repository text NOT NULL,
    id bigint NOT NULL,
    collected_at timestamptz NOT NULL,
    number integer NOT NULL,
    url text NOT NULL,
    title text NOT NULL,
    state text NOT NULL,
    created_at timestamptz NOT NULL,
    labels text[] NOT NULL,
    PRIMARY KEY (repository, id, collected_at)
);

INSERT INTO compass.issue_observations
    (repository, id, collected_at, number, url, title, state, created_at, labels)
SELECT repository, id, collected_at, number, url, title, state, created_at, labels
FROM public.issues
ON CONFLICT (repository, id, collected_at) DO NOTHING;

-- A replay may repeat an observation; a different value needs a new observation time.
DO $$
BEGIN
    IF EXISTS (
        SELECT FROM public.issues i
        JOIN compass.issue_observations o USING (repository, id, collected_at)
        WHERE (i.number, i.url, i.title, i.state, i.created_at, i.labels)
            IS DISTINCT FROM (o.number, o.url, o.title, o.state, o.created_at, o.labels)
    ) THEN
        RAISE EXCEPTION 'Conflicting values at an existing observation time';
    END IF;
END $$;

CREATE OR REPLACE VIEW compass.issue_labels AS
SELECT o.repository, o.id, o.collected_at, l.label
FROM compass.issue_observations o
CROSS JOIN LATERAL unnest(o.labels) AS l(label);

CREATE OR REPLACE VIEW compass.baseline_issues AS
SELECT repository, id, collected_at, number, url, title, state, created_at, labels,
       (collected_at AT TIME ZONE 'UTC')::date
         - (created_at AT TIME ZONE 'UTC')::date AS age_days
FROM compass.issue_observations
WHERE repository = 'openai/codex'
  AND created_at >= TIMESTAMPTZ '2026-11-01 00:00:00+00'
  AND created_at <  TIMESTAMPTZ '2026-11-08 00:00:00+00'
  AND collected_at = TIMESTAMPTZ '2026-11-14 18:25:28.780379+00';

-- One row per selected label on an open bug in the fixed baseline.
CREATE OR REPLACE VIEW compass.problem_tags AS
SELECT unnest(ARRAY['connectivity','sandbox','session','model-behavior',
                    'rate-limits','performance','tool-calls','auth']) AS label;

CREATE OR REPLACE VIEW compass.baseline_memberships AS
SELECT b.id, l.label
FROM compass.baseline_issues b
CROSS JOIN LATERAL unnest(b.labels) AS l(label)
JOIN compass.problem_tags t ON t.label = l.label
WHERE b.state = 'open' AND 'bug' = ANY(b.labels);

-- One row per selected issue. Use COUNT(*) here for the unfiltered review list.
CREATE OR REPLACE VIEW compass.baseline_review AS
SELECT b.id, b.number, b.title, b.url, b.created_at, b.age_days,
       m.selected_labels, cardinality(m.selected_labels) AS label_count
FROM compass.baseline_issues b
JOIN (
    SELECT id, array_agg(label ORDER BY label) AS selected_labels
    FROM compass.baseline_memberships
    GROUP BY id
) m USING (id);

-- Consecutive observed states. A change between snapshots does not date the event.
CREATE OR REPLACE VIEW compass.issue_history AS
SELECT repository, id, number, collected_at, state,
       lag(collected_at) OVER chronology AS previous_observation,
       lag(state) OVER chronology AS previous_state,
       labels, lag(labels) OVER chronology AS previous_labels
FROM compass.issue_observations
WINDOW chronology AS (PARTITION BY repository, id ORDER BY collected_at);

-- Filter by the later observation time to inspect the fixed cohort after a refresh.
-- Missing on a subsequent pull creates no observation and therefore no false exit.
CREATE OR REPLACE VIEW compass.cohort_changes AS
WITH cohort AS (
    SELECT h.*, ARRAY(SELECT label FROM compass.problem_tags) AS tags
    FROM compass.issue_history h
    JOIN compass.issue_observations o USING (repository, id, collected_at)
    WHERE h.repository = 'openai/codex'
      AND o.created_at >= TIMESTAMPTZ '2026-11-01 00:00:00+00'
      AND o.created_at <  TIMESTAMPTZ '2026-11-08 00:00:00+00'
), flags AS (
    SELECT *, state = 'open' AND 'bug' = ANY(labels) AND labels && tags AS selected_now,
           previous_state = 'open' AND 'bug' = ANY(previous_labels)
               AND previous_labels && tags AS selected_before
    FROM cohort
)
SELECT id, number, previous_observation, collected_at, previous_state, state,
       previous_labels, labels, selected_before, selected_now,
       CASE WHEN previous_observation IS NULL THEN 'first observation'
            WHEN selected_now AND NOT selected_before THEN 'entered selection'
            WHEN selected_before AND NOT selected_now THEN 'left selection'
            ELSE 'same membership' END AS membership_change
FROM flags;
COMMIT;
