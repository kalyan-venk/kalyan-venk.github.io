# Product Compass

Which reported problem deserves investigation first? Explore the [interactive case](https://kalyanvenk.com/product-compass/) or reproduce the analysis locally. The public demo uses GitHub issue numbers, labels and short case notes. The source population is 1,159 open and closed Codex reports created November 1–7, 2026 UTC.

## Reproduce the baseline

Requires Python 3.10+ and PostgreSQL. Start with a new database. Set DATABASE_URL if your local connection uses a different host or role.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
createdb product_compass_demo
export DATABASE_URL='postgresql://localhost/product_compass_demo'
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f issues.sql
python load_issues.py baseline.public.json.gz
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f reporting.sql -f check_reporting.sql
psql "$DATABASE_URL" -f analysis.sql
```

The public baseline retains the real IDs, state, timestamps, labels and comment counts. Issue numbers replace titles and the body is omitted. The 10 SQL checks reproduce the published totals on this projection. Keep raw downloads private and use a fresh database for this edition.

## Verify a refresh offline

The portfolio evidence download includes 2 later API responses projected in the same way as the baseline. The full response has 1,159 reports and the update-only response has 155. These files describe observations of the same fixed creation cohort. Reading 155 records instead of 1,159 reduced input volume by 86.6% in this comparison. It does not measure platform costs or support hours.

```bash
python verify_refresh.py baseline.public.json.gz full.public.json delta.public.json
```

The check creates a disposable verification database, rolls back an interrupted update, retries it, replays it, compares both result sets field by field and removes its own test database. It requires local permission to create a database. The observation timestamp differs by design between a full observation and a selective update; the comparison covers the issue ID and all source-derived fields.

## Collect another real observation

```bash
python refresh.py --full
python refresh.py
```

The first command reobserves every issue in the cohort. The second searches for updates from 5 minutes before the last committed run started. Each run checks pagination and source IDs, writes a dated JSON under `data/` and commits the verified issue rows, observations and checkpoint together. If interrupted after the download, run `python refresh.py --replay data/<saved-file>.json`. A committed batch can be replayed without adding observations. GitHub access can be anonymous or use GH_TOKEN; a denied or incomplete request stops the run. Compare raw-to-raw or projected-to-projected when measuring changes across fields.

The SQL views preserve the November 14 baseline as new observations arrive. The website contains no database credentials and sends no requests to reporters.

## Check the operational screening rule

Run `python evaluate_triage.py` to see which of 24 held-out reports a frozen title-keyword rule flagged or missed. The reference labels come from one reading of each report body. Two reports did not establish the task impact and are reported separately. The rule missed 11 of 20 reported blockers, so using it as the only screen would hide reports worth investigating.
