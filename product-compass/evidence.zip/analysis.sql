-- The November 14 observation remains the basis of the published chart after refreshes.
SELECT label AS problem_tag, count(DISTINCT id) AS issue_count
FROM compass.baseline_memberships
GROUP BY label
ORDER BY issue_count DESC, problem_tag;
